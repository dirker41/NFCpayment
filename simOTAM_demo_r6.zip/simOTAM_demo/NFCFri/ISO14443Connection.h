////////////////////////////////////////////////////
//
//  Copyright 2013 CHT. All rights reserved.
//
////////////////////////////////////////////////////

#import <Foundation/Foundation.h>

#define ISO14443Connection id <_ISO14443Connection>

@protocol _ISO14443Connection

- (NSData *) exchangeData:(NSData *)data;
- (NSData *) exchangeData:(NSData *)data timeout:(NSTimeInterval) secs; 
- (void) close;
- (NSData *) getWiredCardRPPS;
- (NSData *) getWiredCardATR;  
- (NSData*) getISO14443HistBytes;

@end
