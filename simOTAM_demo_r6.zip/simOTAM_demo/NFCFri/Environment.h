////////////////////////////////////////////////////
//
//  Copyright 2013 CHT. All rights reserved.
//
////////////////////////////////////////////////////


#import <Foundation/Foundation.h>
#import "MessageHandler.h"

@interface Environment : NSObject {

}
+ (void) setPBTF:(BOOL) pbtfOn;
+ (BOOL) getPBTF;  
+ (BOOL) checkDevAvailable;
+ (void) regDevList:(id <MessageHandler>) handler;	// deprecated.
+ (void) enumerateDevList:(id <MessageHandler>) handler;	
+ (void) setEventListener:(id <MessageHandler>) handler;
+ (void) setDevName:(NSString *) name;
+ (void) setEcoMode:(int) time;
+ (int) getEcoMode;
+ (BOOL) stopPrevService; 
+ (int) getBattery:(NSString *) addr; 
+ (id) libInitialize: (id)listener ; 
+ (void) libDeInit; 
+ (void) enableHotPlug;
+ (void) disableHotPlug;
+ (NSString*) getDeviceName;
+ (BOOL) checkLibInitAvailable; 
@end
