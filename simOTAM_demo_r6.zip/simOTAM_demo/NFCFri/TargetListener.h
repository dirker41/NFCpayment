////////////////////////////////////////////////////
//
//  Copyright 2013 CHT. All rights reserved.
//
////////////////////////////////////////////////////


#import <UIKit/UIKit.h>

@protocol TargetListener


- (void) targetDetected:(NSArray *)properties;
- (void) errorDetected:(int)errorCode message:(NSString *)message;
- (void) discoveryDetected:(NSString *)string;

@end
