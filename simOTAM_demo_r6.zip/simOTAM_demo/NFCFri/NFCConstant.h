////////////////////////////////////////////////////
//
//  Copyright 2013 CHT. All rights reserved.
//
////////////////////////////////////////////////////


// NDEF record type
#define NDEFRECORD_EMPTY			0
#define NDEFRECORD_NFC_FORUM_RTD	1
#define NDEFRECORD_MIME				2
#define NDEFRECORD_URI				3
#define NDEFRECORD_EXTERNAL_RTD		4
#define NDEFRECORD_UNKNOWN			5

// Environment power configration
#define POWER_SAVING_MAX			1
#define POWER_SAVING_NORMAL			2
#define POWER_SAVING_OFF			3
