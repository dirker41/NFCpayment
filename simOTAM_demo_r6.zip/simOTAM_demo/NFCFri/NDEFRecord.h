////////////////////////////////////////////////////
//
//  Copyright 2013 CHT. All rights reserved.
//
////////////////////////////////////////////////////


#import <Foundation/Foundation.h>
#import "NDEFRecordType.h"

@class NDEFMessage;

@interface NDEFRecord : NSObject {
@private
	NDEFRecordType *_recordType;
	NSData *_payload;
	NSData *_ID;
    uint8_t _RecordHead; //3.0.0.3
}

- (BOOL) isMB;
- (BOOL) isME;
- (BOOL) isCF;
- (BOOL) isSR;
- (NSMutableArray *) initWithDataInArray:(NSData *)data;
- (NDEFRecord*) createUri:(NSString *) uri;
- (NDEFRecord*) createText:(NSString *) text;



- (NDEFRecord*) createUri:(uint8_t) abbreviation:(NSString *) uri;
- (NDEFRecord*) createText:(uint8_t) encoding lang_code:(NSString*) lang_code  text:(NSString *) text;
- (NDEFRecord*) createSmartPoster:(uint8_t) abbreviation uri:(NSString *) uri title:(NSString *)title action:(uint8_t) action;



- (NDEFRecord*) createTextByData:(NSData *) uriData;


- (NDEFRecord *) copy;
- (NDEFRecord *) initWithData:(NSData *)data;
- (NDEFRecord *) initWithRecordType:(NDEFRecordType *)recordType ID:(NSData *)ID payload:(NSData *)payload;
- (NDEFRecordType *) getRecordType;
- (NSData *) getId;
- (void)setId:(NSData *)ID;
- (NSData *) getPayload;

- (void) appendPayload:(NSData *)payload;
- (int) getPayloadLength;

- (NDEFMessage *)getNestedNDEFMessage:(int) offset;

- (NSData *) bytes;
@end
