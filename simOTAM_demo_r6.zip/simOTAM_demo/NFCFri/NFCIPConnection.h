////////////////////////////////////////////////////
//
//  Copyright 2013 CHT. All rights reserved.
//
////////////////////////////////////////////////////


#import <Foundation/Foundation.h>

#define NFCIPConnection id <_NFCIPConnection>

@protocol _NFCIPConnection

- (void) send:(NSData *) information;
- (NSData *)receive;
- (void) close;
- (NSData *)exchangeData:(NSData *) information;

@end
