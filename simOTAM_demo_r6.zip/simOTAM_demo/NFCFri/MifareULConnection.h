////////////////////////////////////////////////////
//
//  Copyright 2013 CHT. All rights reserved.
//
////////////////////////////////////////////////////


#import <Foundation/Foundation.h>

#define MifareULConnection id <_MifareULConnection>

#define TAG_PAGE_SIZE 0x00000004	//Size of a MIFARE Ultralight page in bytes
#define TYPE_ULTRALIGHT 0x00000001//A MIFARE Ultralight tag
#define TYPE_ULTRALIGHT_C 0x00000002	//A MIFARE Ultralight C tag
#define TYPE_UNKNOWN 0xffffffff	//A MIFARE Ultralight compatible tag of unknown type


@protocol _MifareULConnection

- (void) close;

-(void) connect;
-(int) getMaxTransceiveLength;
-(int) getTimeout;
-(int) getType;
-(BOOL) isConnected;
-(NSData*) readPages:(int) pageOffset;
-(void) setTimeout:(int) timeout;
-(NSData*) transceive:(NSData*) data;
-(BOOL)	writePage:(int) pageOffset :(NSData*) writeData;
- (BOOL) erase;

@end
