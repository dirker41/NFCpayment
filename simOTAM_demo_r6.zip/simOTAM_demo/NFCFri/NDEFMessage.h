////////////////////////////////////////////////////
//
//  Copyright 2013 CHT. All rights reserved.
//
////////////////////////////////////////////////////


#import <Foundation/Foundation.h>
#import "NDEFRecordType.h"
#import "NDEFRecord.h"

@interface NDEFMessage : NSObject {
@private
	NSMutableArray *_records;
}

- (NDEFMessage *) initWithRecord:(NDEFRecord *) input;

- (NDEFMessage *) initWithRecords:(NSArray *) records;
- (NDEFMessage *) initWithData:(NSData *)data;
- (int) getNumberOfRecords;
- (NSArray *) getRecordTypes;
- (NDEFRecord *) getRecordAtIndex:(int)index;
- (NSArray *) getRecordFromType:(NDEFRecordType *)recordType;
- (NDEFRecord *) getRecordByID:(NSData *) ID;
- (NSArray *) getRecords;
- (void) setRecord:(int)index record:(NDEFRecord *)record;
- (void) appendRecord:(NDEFRecord *)record;
- (void) insertRecord:(int)index record:(NDEFRecord *)record;
- (void) removeRecord:(int) index;
- (NSData *) bytes;

@end
