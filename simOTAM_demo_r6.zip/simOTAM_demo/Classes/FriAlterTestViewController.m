////////////////////////////////////////////////////
//
//  Copyright 2013 CHT. All rights reserved.
//
////////////////////////////////////////////////////


#import <AudioToolbox/AudioToolbox.h>
#import <Foundation/NSUserDefaults.h>
#import "FriAlterTestViewController.h"
#import "iToast.h"
#import "LoadingView.h"

#import "simOTAManager.h"

#define PBTFSWITCHKEY @"pbtfSwitchKey"

simOTAManager *otam=nil;
NSString* msg=nil;
ISO14443Connection conn = nil;
int tar_num=0;
 BOOL resProcess=TRUE;

int readCount = 0;
int sleepInterval = 3;
NSThread *p2pThread=nil;
LoadingView *loadingView=nil;

@interface FriAlterTestViewController (hidden)
/*private local variable here*/

/* private methon here */
@end


@implementation FriAlterTestViewController


@synthesize pbtfSwitch;

static DiscoveryManager *discoveryManager;

/* error report interface (from TargetListener) */
- (void) errorDetected:(int)errorCode message:(NSString *)message
{
	NSString *msg = nil;
	switch (errorCode) {
		case MSG_NFC_SERVICE_CONNECT_FAILED:
			msg=[[NSString alloc] initWithFormat:@"APP: errorDetected Service connect failed.readCount:%d sleepInterval:%d",readCount,sleepInterval];
			NSLog(@"APP: errorDetected Service connect failed.readCount:%d",readCount);
			break;
		case MSG_NFC_DEVICE_OPEN_FAILED:
			msg=[[NSString alloc]  initWithFormat:@"APP: errorDetected Device open error. readCount:%d sleepInterval:%d",readCount,sleepInterval];
			NSLog(@"APP: errorDetected Device open error. readCount:%d",readCount);
			break;              
        case MSG_NFC_DEVICE_CLOSE_FAILED:             
			msg=[[NSString alloc]  initWithFormat:@"APP: errorDetected Device close error"];
			NSLog(@"APP: errorDetected Device close error");
			break;            
		case MSG_NFC_DATA_EXCHANGE_FAILED:      
			msg=[[NSString alloc] initWithFormat:@"APP: errorDetected Exchange failed.readCount:%d sleepInterval:%d",readCount,sleepInterval];		
			NSLog(@"APP: errorDetected Exchange failed.");			
			break;  
		case MSG_NFC_POLLING_TIMEOUT:
			msg=[[NSString alloc] initWithFormat:@"APP: errorDetected Exchange failed.readCount:%d sleepInterval:%d",readCount,sleepInterval];		
			NSLog(@"APP: errorDetected polling timeout.");
			break;
		default:
			NSLog(@"errorDetected, with unknown code: 0x%x, message:%@",errorCode,message);
			msg =@"APP: errorDetected default.";
			break;  
	}
	if(msg!=nil){
        [self performSelectorOnMainThread:@selector(showmsg:) withObject:msg waitUntilDone:TRUE]; 
	}  
	[msg release];      	      
}      

- (void) showmsg:(NSString *)msg  
{
    AudioServicesPlaySystemSound (kSystemSoundID_Vibrate);
    if (msg== nil) {
        NSLog(@"msg is nil");
        msg = @"msg is nil";                
    }
    else{
        NSLog(@"%@",msg);         
    }  

#if 1
    UIAlertView *alert = [[UIAlertView alloc]    
                          initWithTitle:@"App"   
                          message:msg  
                          delegate:self   
                          cancelButtonTitle:@"OK"
                          otherButtonTitles:nil];
    [alert show];
    [alert release];alert=nil;
#endif
}


/* showing array data */
- (NSString*) showArray:(NSString *)message array:(NSData *)array
{
	NSString *tmp = @"";
	const UInt8 *src = [array bytes];
	for (int i = 0; i < [array length]; i++) {
		tmp = [tmp stringByAppendingFormat:@"%02x,", src[i]];
	}
    NSString* retStr=[message stringByAppendingString:tmp];
	NSLog(@"%@",retStr);
    return [retStr copy];
}
   
/*============End of Utilities==========================*/
/* error report interface or msg (from Lib) */
- (void)handleMessage:(int) msg data:(NSArray *)data
{
	NSLog(@"App message:0x%x tested by frankou", msg);
	switch (msg) {
        case MSG_NFC_DEVICE_SERVICE_OPENED:
        { 
            NSString* result=[[data valueForKey:@"description"] componentsJoinedByString:@""];
            [self performSelectorOnMainThread:@selector(showmsg:) withObject:result waitUntilDone:TRUE];   
            discoveryManager = [DiscoveryManager sharedDiscoveryManager]; /* 2.0.7 refresh the handle*/
            break;    
        }    	
        case MSG_NFC_DEVICE_OPEN_FAILED:   
        {
			NSLog(@"handleMessage: Device open failed. ");  
            [self performSelectorOnMainThread:@selector(showmsg:) withObject:@"init failed" waitUntilDone:TRUE];   
			break;	    
        }
        case MSG_NFC_INTERNAL_ERROR:      
        {
            NSLog(@"handleMessage: Lib internal error. ");  
            [self performSelectorOnMainThread:@selector(showmsg:) withObject:@"internal library error" waitUntilDone:TRUE];                      
			break;  
        }
		default:     
			NSLog(@"handleMessage: Unhandle message:0x%x",(unsigned)msg);
			break;  
	}  
} 

- (IBAction) otainstall:(id)sender
{    
    NSLog(@"OTA install..");    
    msg=nil;
    resProcess=TRUE;
        
    if (loadingView == nil) {
        loadingView = [LoadingView loadingViewInView:self.view];
        [loadingView settext:@"OTA install..."];
    }
    
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        
        //otam = [[simOTAManager alloc] init];
        otam = [[simOTAManager alloc] initWithServerIP:@"61.220.220.201" Port:4105];
//        otam = [[simOTAManager alloc] initWithServerIP:@"140.135.11.174" Port:4105];

        if (otam!=nil) {
            NSLog(@"otam init ok ");
        }      
        else{
            NSLog(@"otam init fail");
            msg=[[NSString alloc] initWithString:@"otam init fail"];
        }
        
        
        if ([otam requestInstall] == FALSE) {
            NSLog(@"OTA install fail");
            msg = [[NSString alloc] initWithFormat:@"OTA install fail"];
        }
        else{
            while ([otam getApduNum]<=0) //wait and fetch the number of apdus from OTA server
            {
                [NSThread sleepForTimeInterval:0.3];
            }
            tar_num = [otam getApduNum];
            NSLog(@"apdu num:%d",tar_num);
            if (tar_num<0) {
                NSLog(@"OTA install fail 2");
                msg = [[NSString alloc] initWithFormat:@"OTA install fail"];
            } 
            else{     
                @try { 
                    conn = (ISO14443Connection) [[ConnectionFactory sharedConnectionFactory] open:@"nfc:InternalISO14443"];
                    bool flag=FALSE;
                    for (int i=0; i<tar_num && flag== FALSE; i++) {
                        NSLog(@"index:%d",i);
                        NSData* resp=nil;
                        NSData* cmd=nil;
                        
                        cmd=(NSData*)[otam getApdu];//fetch one apdu cmd
                        int cc=0;
                        while (cmd==nil && flag == FALSE) //fetch another one apdu cmd if previous one doesnot exist
                        {
                            if ([otam checkOTAServerConnection]) //check the connection is available
                            { 
                                [NSThread sleepForTimeInterval:0.5];
                                NSLog(@".");
                                flag = [otam check_end_of_apdus]; //check if no more apdu received
                                if (flag==FALSE) {
                                    cmd=(NSData*)[otam getApdu];//fetch one apdu
                                }
                                
                                if (cc > 60) {
                                    flag = TRUE;
                                }
                                cc++;
                            }
                            else{
                                resProcess=FALSE;
                                break;
                            }                            
                        }
                        NSLog(@"index:%d write:%@",i,cmd);
                        if (cmd==nil) {
                            msg=[[NSString alloc] initWithFormat:@"OTA install fail: index:%d write:%@",i,cmd];
                            resProcess=FALSE;
                            break; 
                        }
                        else{
                            resp=[conn exchangeData:cmd timeout:1.0]; //write apdu to SE and receive the response 
                            NSLog(@"index:%d resp:%@",i,resp);
                            
                            if (resp!=nil) {
                                uint8_t* buf=(uint8_t*)[resp bytes];
                                [otam reponseWithData:resp]; //forward the response back to OTA server
                                if (buf[[resp length]-2]!=0x90 && buf[[resp length]-2]!=0x00 ) {
                                    msg=[[NSString alloc] initWithFormat:@"OTA install: fail stop %@",resp];
                                    break;    
                                }
                            }
                            else{
                                msg=[[NSString alloc] initWithFormat:@"OTA install: fail stop %@",resp];
                                break;
                            }
                            
                            //refresh the progress notification view
                            dispatch_async(dispatch_get_main_queue(),^{
                                [loadingView settext:[NSString stringWithFormat:@"OTA install: %d/%d",i,tar_num]];
                            });
                        }                        
                    }
                    
                    if (resProcess) {
                        NSLog(@"resp ok ...");
                        [otam reponse_ok];
                        NSLog(@"resp ok done");
                    }
                }
                @catch (NSException *exception) {
                    msg = [[NSString alloc] initWithFormat:@"OTA install fail"];
                    NSLog(@"OTA install fail 3");
                }
                @finally {
                    [conn close];
                }
            }
        }
        if (otam!=nil) {
            NSLog(@"otam destroy..");
            [otam destroy];
            otam=nil;
            NSLog(@"otam destroy ok");
        }
        dispatch_async(dispatch_get_main_queue(),^{
            [loadingView removeView];
            loadingView = nil;
            if(msg==nil)
                msg = [[NSString alloc] initWithFormat:@"OTA install: OK"];
            [self showmsg:msg];
            msg=nil;
        });
    });
}
 
- (IBAction) otadelete: (id) sender
{
    NSLog(@"OTA delete..");
    msg=nil;
    resProcess=TRUE;
        
    if (loadingView == nil) {
        loadingView = [LoadingView loadingViewInView:self.view];
        [loadingView settext:@"OTA delete..."];
    }
    
    dispatch_async(dispatch_get_global_queue(0, 0), ^{

        //otam = [[simOTAManager alloc] init];
        otam = [[simOTAManager alloc] initWithServerIP:@"61.220.220.201" Port:4105];
//        otam = [[simOTAManager alloc] initWithServerIP:@"140.135.11.174" Port:4105];

        if (otam!=nil) {
            NSLog(@"otam init ok ");
        } 
        else{
            NSLog(@"otam init fail");
            msg=[[NSString alloc] initWithString:@"otam init fail"];
        }
        
        if ([otam requestDelete] == FALSE) {
            NSLog(@"OTA delete fail");
            msg = [[NSString alloc] initWithFormat:@"OTA delete fail"];
        }
        else{
            while ([otam getApduNum]<=0) //wait and fetch the number of apdus from OTA server
            {
                [NSThread sleepForTimeInterval:0.3];
            }
            tar_num = [otam getApduNum];
            NSLog(@"apdu num:%d",tar_num);
            if (tar_num<0) {
                NSLog(@"OTA delete fail 2");
                msg = [[NSString alloc] initWithFormat:@"OTA delete fail"];
            }
            else{
                @try {
                    conn = (ISO14443Connection) [[ConnectionFactory sharedConnectionFactory] open:@"nfc:InternalISO14443"];
                    bool flag=FALSE;
                    for (int i=0; i<tar_num && flag== FALSE; i++) {
                        NSLog(@"index:%d",i);
                        NSData* resp=nil;
                        NSData* cmd=nil;
                        
                        cmd=(NSData*)[otam getApdu];//fetch one apdu cmd
                        int cc=0;
                        while (cmd==nil && flag == FALSE) //fetch another one apdu cmd if previous one doesnot exist
                        {
                            if ([otam checkOTAServerConnection]) //check the connection is available
                            {
                                [NSThread sleepForTimeInterval:0.5];
                                NSLog(@".");
                                flag = [otam check_end_of_apdus]; //check if no more apdu received
                                if (flag==FALSE) {
                                    cmd=(NSData*)[otam getApdu];//fetch one apdu
                                }
                                
                                if (cc > 60) {
                                    flag = TRUE;
                                }
                                cc++;
                            }
                            else{
                                resProcess=FALSE;
                                break;
                            }
                        }
                        NSLog(@"index:%d write:%@",i,cmd);
                        if (cmd==nil) {
                            msg=[[NSString alloc] initWithFormat:@"OTA delete fail: index:%d write:%@",i,cmd];
                            resProcess=FALSE;
                            break;
                        }
                        else{
                            resp=[conn exchangeData:cmd timeout:1.0]; //write apdu to SE and receive the response
                            NSLog(@"index:%d resp:%@",i,resp);
                            
                            if (resp!=nil) {
                                uint8_t* buf=(uint8_t*)[resp bytes];
                                [otam reponseWithData:resp]; //forward the response back to OTA server
                                
                                if (buf[[resp length]-2]!=0x90 && buf[[resp length]-1]!=0x00 ) {
                                    
                                    if(buf[[resp length]-2]==0x6A && buf[[resp length]-1] == 0x88){
                                        NSLog(@"Skip 6A 88");
                                        
                                    }else{
                                        msg=[[NSString alloc] initWithFormat:@"OTA delete: fail stop %@",resp];
                                        break;
                                    }
                                }
                            }
                            else{
                                msg=[[NSString alloc] initWithFormat:@"OTA delete: fail stop %@",resp];
                                break;
                            }
                            
                            //refresh the progress notification view
                            dispatch_async(dispatch_get_main_queue(),^{
                                [loadingView settext:[NSString stringWithFormat:@"OTA delete: %d/%d",i,tar_num]];
                            });
                        }
                    }
                    
                    if (resProcess) {
                        NSLog(@"resp ok ...");
                        [otam reponse_ok];
                        NSLog(@"resp ok done");
                    }
                }
                @catch (NSException *exception) {
                    msg = [[NSString alloc] initWithFormat:@"OTA delete fail"];
                    NSLog(@"OTA delete fail 3");
                }
                @finally {
                    [conn close];
                }
            }
        } 
        if (otam!=nil) {
            NSLog(@"otam destroy..");
            [otam destroy];
            otam=nil;
            NSLog(@"otam destroy ok");
        }
        dispatch_async(dispatch_get_main_queue(),^{
            [loadingView removeView];
            loadingView = nil;
            if(msg==nil)
                msg = [[NSString alloc] initWithFormat:@"OTA delete: OK"];
            [self showmsg:msg];  
            msg=nil;
        }); 
    }); 
}

- (IBAction) libReInit:(id)sender
{
    NSLog(@"lib re-init..");
    discoveryManager=[Environment libInitialize:self];    
    NSLog(@"lib re-init done");
}    
 
- (IBAction) deinit:(id)sender 
{
	NSLog(@"deinit");       
    [Environment libDeInit];
	NSLog(@"deinit done");
}    
  
- (void)viewDidLoad {
    [super viewDidLoad];      
    discoveryManager=[Environment libInitialize :self]; 
   
}
  
- (void)didReceiveMemoryWarning { 
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
    [self deinit:nil];  
}

- (void)dealloc {
    [super dealloc];
}

@end

