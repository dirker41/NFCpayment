////////////////////////////////////////////////////
//
//  Copyright 2013 CHT. All rights reserved.
//
////////////////////////////////////////////////////

#import <UIKit/UIKit.h>

@class FriAlterTestViewController;       

@interface FriAlterTestAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    FriAlterTestViewController *viewController;    
}
@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet FriAlterTestViewController *viewController;

@end

