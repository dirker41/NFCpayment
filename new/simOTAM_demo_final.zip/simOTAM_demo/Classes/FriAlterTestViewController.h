////////////////////////////////////////////////////
//
//  Copyright 2013 CHT. All rights reserved.
//
////////////////////////////////////////////////////

#import <UIKit/UIKit.h>
#import "NFCFRILite.h"


@interface FriAlterTestViewController : UIViewController <TargetListener, NDEFRecordListener, MessageHandler> {
	IBOutlet UISwitch* pbtfSwitch;
}
@property (nonatomic, retain) UISwitch *pbtfSwitch;

- (IBAction) otainstall: (id) sender;
- (IBAction) otadelete: (id) sender;
- (IBAction) deinit: (id) sender;
- (IBAction) libReInit:(id)sender;

@end

