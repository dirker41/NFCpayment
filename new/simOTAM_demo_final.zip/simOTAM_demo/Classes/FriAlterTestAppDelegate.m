////////////////////////////////////////////////////
//
//  Copyright 2013 CHT. All rights reserved.
//
////////////////////////////////////////////////////

#import "FriAlterTestAppDelegate.h"
#import "FriAlterTestViewController.h"

@implementation FriAlterTestAppDelegate

@synthesize window;
@synthesize viewController;

static bool reInitNeed = FALSE; 

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {    
    
    // Override point for customization after app launch    
    [window addSubview:viewController.view];
    [window makeKeyAndVisible];
	
	return YES;
}

/*
- (void)defaultsChanged:(NSNotification *)notification {
    // Get the user defaults
    NSUserDefaults *defaults = (NSUserDefaults *)[notification object];
    
    // Do something with it
    NSLog(@"%@", [defaults objectforKey:@"nameOfThingIAmInterestedIn"]);
}*/


- (void)applicationDidBecomeActive:(UIApplication *)application {
    if (reInitNeed) {
        while([Environment checkDevAvailable]!=TRUE) {
            [NSThread sleepForTimeInterval:0.3];
            NSLog(@"Forground,check device..");
        }
        [viewController libReInit:nil];
        reInitNeed = FALSE; 
    }
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    /*
     Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
     If your application supports background execution, called instead of applicationWillTerminate: when the user quits.
     */    
	//exit(0);
    //[viewController disableHP:nil];
    [viewController deinit:nil];  
    reInitNeed = TRUE; /*2.0.7*/
#define EXIT_WHEN_BACKGROUND  
#ifdef EXIT_WHEN_BACKGROUND 
    [self dealloc];
    exit(0);
#endif
}

- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}


@end
