////////////////////////////////////////////////////
//
//  Copyright 2013 CHT. All rights reserved.
//
////////////////////////////////////////////////////


// Message for client 

// information
#define MSG_NFC_SERVICE_OPENED			0x20     //32
#define MSG_NFC_SERVICE_CLOSED			0x21     //33 
#define MSG_NFC_DEVICE_SERVICE_OPENED   0x22     //34 /*2.0.5.11*/
#define MSG_DEV_LIST					0x90     //
#define MSG_DEV_LIST_FAILED				0x91     //
// error
#define MSG_NFC_SERVICE_CONNECT_FAILED	0x30     //48
#define MSG_NFC_DEVICE_OPEN_FAILED		0x31     //49 
#define MSG_NFC_DATA_EXCHANGE_FAILED	0x32     //50 
#define MSG_NFC_POLLING_TIMEOUT			0X33     //51
#define MSG_NFC_DEVICE_CLOSE_FAILED		0x34
#define MSG_NFC_INTERNAL_ERROR          0x35     /*2.0.2.9*/
