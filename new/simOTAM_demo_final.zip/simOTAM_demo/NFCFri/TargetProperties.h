////////////////////////////////////////////////////
//
//  Copyright 2013 CHT. All rights reserved.
//
////////////////////////////////////////////////////


#import <Foundation/Foundation.h>
#import "TargetType.h"

#define TargetProperties id <_TargetProperties>
@protocol _TargetProperties


- (NSArray *) getTargetTypes;
- (BOOL) hasTargetType:(TargetType *) type;
- (NSString *) getUrl;
- (NSString *) getUrl:(NSString *)connectionName;
- (NSString *) getUid;
- (NSData *) getUidBytes;
- (NSArray *) getConnectionNames;
- (NSString *) getMapping;
- (NSString *) getProperty:(NSString *) name;
@end
