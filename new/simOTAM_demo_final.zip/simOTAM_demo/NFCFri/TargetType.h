////////////////////////////////////////////////////
//
//  Copyright 2013 CHT. All rights reserved.
//
////////////////////////////////////////////////////


#import <Foundation/Foundation.h>

@interface TargetType : NSObject {
@private
	NSString *_typeName;
}

- (TargetType *) initWithType:(NSString *) type;
+ (TargetType *) ISO14443_CARD;
+ (TargetType *) NDEF_TAG;
+ (TargetType *) PLAIN_TAG;
+ (TargetType *) ISO15693_CARD;
+ (TargetType *) MIFARE_TAG;

@end
