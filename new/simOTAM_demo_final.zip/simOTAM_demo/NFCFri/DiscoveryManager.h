////////////////////////////////////////////////////
//
//  Copyright 2013 CHT. All rights reserved.
//
////////////////////////////////////////////////////


#import <Foundation/Foundation.h>
#import "TargetListener.h"
#import "NDEFRecordType.h"
#import "NDEFRecordListener.h"
#import "TargetType.h"

@interface DiscoveryManager : NSObject {

}
+ (DiscoveryManager *) sharedDiscoveryManager;
+ (NSArray *) getSupportedTargetTypes;
- (void) addTargetListener:(id <TargetListener>) listener targetType:(TargetType *) targetType;
- (void) removeTargetListener:(id <TargetListener>) listener targetType:(TargetType *) targetType;
- (void) addNDEFRecordListener:(id <NDEFRecordListener>) listener recordType:(NDEFRecordType *) recordType;
- (void) removeNDEFRecordListener:(id <NDEFRecordListener>) listener recordType:(NDEFRecordType *) recordType;
- (NSString *) getProperty:(NSString *) name;
- (void) setProperty:(NSString *) name value:(NSString *)value;
- (BOOL) closeDevice; 
- (BOOL) isRegistered;
- (BOOL) holdDetectedTarget;

@end
