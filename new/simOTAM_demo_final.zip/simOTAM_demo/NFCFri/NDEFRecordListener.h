////////////////////////////////////////////////////
//
//  Copyright 2013 CHT. All rights reserved.
//
////////////////////////////////////////////////////


#import <UIKit/UIKit.h>
#import "NDEFMessage.h"

@protocol NDEFRecordListener

- (void) recordDetected:(NDEFMessage *) ndefMessage;
- (void) errorDetected:(int) errorCode message:(NSString *)message;
- (void) discoveryDetected:(NSString *)string;
@end
