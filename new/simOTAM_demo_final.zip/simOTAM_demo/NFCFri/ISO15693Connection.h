////////////////////////////////////////////////////
//
//  Copyright 2013 CHT. All rights reserved.
//
////////////////////////////////////////////////////


#import <Foundation/Foundation.h>

#define ISO15693Connection id <_ISO15693Connection>

@protocol _ISO15693Connection

- (NSData *) exchangeData:(NSData *)data;
- (void) close;
- (NSData *) readBlockByIndex:(int)blockIndex;
@end
