////////////////////////////////////////////////////
//
//  Copyright 2013 CHT. All rights reserved.
//
////////////////////////////////////////////////////


#import <Foundation/Foundation.h>


#define NDEFRECORDTYPE_RTD_URI_ABB_NA           0X00
#define NDEFRECORDTYPE_RTD_URI_ABB_HTTP_WWW     0X01
#define NDEFRECORDTYPE_RTD_URI_ABB_HTTPS_WWW    0x02
#define NDEFRECORDTYPE_RTD_URI_ABB_HTTP         0x03
#define NDEFRECORDTYPE_RTD_URI_ABB_HTTPS        0x04
#define NDEFRECORDTYPE_RTD_URI_ABB_TEL          0x05
#define NDEFRECORDTYPE_RTD_URI_ABB_MAILTO       0x06
#define NDEFRECORDTYPE_RTD_URI_ABB_FTP_ANONY    0x07
#define NDEFRECORDTYPE_RTD_URI_ABB_FTP_FTP      0x08
#define NDEFRECORDTYPE_RTD_URI_ABB_FTPS         0x09
#define NDEFRECORDTYPE_RTD_URI_ABB_SFTP         0x0A
#define NDEFRECORDTYPE_RTD_URI_ABB_SMB          0x0B
#define NDEFRECORDTYPE_RTD_URI_ABB_NFS          0x0C
#define NDEFRECORDTYPE_RTD_URI_ABB_FTP          0x0D
#define NDEFRECORDTYPE_RTD_URI_ABB_DAV          0x0E
#define NDEFRECORDTYPE_RTD_URI_ABB_NEWS         0x0F
#define NDEFRECORDTYPE_RTD_URI_ABB_TELNET       0x10
#define NDEFRECORDTYPE_RTD_URI_ABB_IMAP         0x11
#define NDEFRECORDTYPE_RTD_URI_ABB_RTSP         0x12
#define NDEFRECORDTYPE_RTD_URI_ABB_URN          0x13
#define NDEFRECORDTYPE_RTD_URI_ABB_POP          0x14
#define NDEFRECORDTYPE_RTD_URI_ABB_SIP          0x15
#define NDEFRECORDTYPE_RTD_URI_ABB_SIPS         0x16
#define NDEFRECORDTYPE_RTD_URI_ABB_TFTP         0x17
#define NDEFRECORDTYPE_RTD_URI_ABB_BTSPP        0x18
#define NDEFRECORDTYPE_RTD_URI_ABB_BTL2CAP      0x19
#define NDEFRECORDTYPE_RTD_URI_ABB_BTGOEP       0x1A
#define NDEFRECORDTYPE_RTD_URI_ABB_TCPOBEX      0x1B
#define NDEFRECORDTYPE_RTD_URI_ABB_IRDAOBEX     0x1C
#define NDEFRECORDTYPE_RTD_URI_ABB_FILE         0x1D
#define NDEFRECORDTYPE_RTD_URI_ABB_FTP_EPC_ID   0x1E
#define NDEFRECORDTYPE_RTD_URI_ABB_FTP_EPC_TAG  0x1F
#define NDEFRECORDTYPE_RTD_URI_ABB_URN_EPC_PAT  0x20
#define NDEFRECORDTYPE_RTD_URI_ABB_URN_EPC_RAW  0x21
#define NDEFRECORDTYPE_RTD_URI_ABB_URN_EPC      0x22
#define NDEFRECORDTYPE_RTD_URI_ABB_URN_NFC      0x23

#define NDEFRECORDTYPE_RTD_SP_ACT_DO        0x00
#define NDEFRECORDTYPE_RTD_SP_ACT_LATER     0x01
#define NDEFRECORDTYPE_RTD_SP_ACT_EDITING   0x02

@interface NDEFRecordType : NSObject {
@private
	NSString *_typeName;
	NSData *_nameAsBytes;
	int _format;
}

- (NDEFRecordType *) initWithFormatAndName:(int) format Name:(NSString *) name;
- (NSString *) getName;
- (NSData *) getNameAsBytes;
- (int) getFormat;
- (BOOL) equals: (NDEFRecordType *) recordType;
- (int) hashCode;

@end
