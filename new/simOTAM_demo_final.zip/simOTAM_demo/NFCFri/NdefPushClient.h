////////////////////////////////////////////////////
//
//  Copyright 2013 CHT. All rights reserved.
//
////////////////////////////////////////////////////

@interface NdefPushClient : NSObject {
@private
}

+(NDEFMessage*) push:(NDEFMessage *) msg;
+(BOOL) pushOnly:(NDEFMessage *) msg;

@end
 



