////////////////////////////////////////////////////
//
//  Copyright 2013 CHT. All rights reserved.
//
////////////////////////////////////////////////////


#import <Foundation/Foundation.h>
#import "NDEFMessage.h"

#define NDEFTagConnection id <_NDEFTagConnection>

@protocol _NDEFTagConnection


- (NDEFMessage *) readNDEF;
- (void) writeNDEF:(NDEFMessage *) message;
- (NSData *) readBlockByIndex:(int)blockIndex;
- (void) close;
@end
