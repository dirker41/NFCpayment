////////////////////////////////////////////////////
//
//  Copyright 2013 CHT. All rights reserved.
//
////////////////////////////////////////////////////


#import <Foundation/Foundation.h>
#import "TagConnection.h"

@interface ConnectionFactory : NSObject {
}

+ (ConnectionFactory *) sharedConnectionFactory;
- (TagConnection *) open:(NSString *)stringUrl;
- (void) close;
- (void) shutdownConn;
+ (void) shutdownAllConn;
- (void) cancel;
+ (TagConnection *) getOpenedTagConnection;
+ (void) setWiredCardConnectionPPS:(NSData *) pps;
@end
