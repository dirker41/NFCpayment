////////////////////////////////////////////////////
//
//  Copyright 2013 CHT. All rights reserved.
//
////////////////////////////////////////////////////


/*Definition Macros*/
#define LLCP_URL @"NFC:RF;TYPE=NFCIP;MODE=LLCP"
#define AUTO_URL @"NFC:RF;TYPE=NFCIP;MODE=AUTO"

/*Deprecated from 2.0.3*/
/*Restored from 2.0.5.4*/
#define TARGET_URL @"NFC:RF;TYPE=NFCIP;MODE=TARGET"
#define INITIATOR_URL @"NFC:RF;TYPE=NFCIP;MODE=INITIATOR"



#define ISO15693_CARD_CONNNECTION @"contactless.sc.ISO15693Connection"
#define ISO14443_CARD_CONNNECTION @"contactless.sc.ISO14443Connection"
#define NDEF_TAG_CONNNECTION @"contactless.ndef.NDEFTagConnection"
#define MIFAREUL_TAG_CONNNECTION @"contactless.tag.MifareULConnection"
#define MIFARE1K_TAG_CONNNECTION @"contactless.tag.Mifare1KConnection"
#define MIFARE4K_TAG_CONNNECTION @"contactless.tag.Mifare4KConnection"



// exception
#import "ContactlessException.h"   
// message & constant
#import "NFCMessage.h"
#import "NFCConstant.h"
// methods
#import "Environment.h"
#import "DiscoveryManager.h"
#import "ConnectionFactory.h"
// interfaces
#import "TargetListener.h"
#import "NDEFRecordListener.h"
#import "MessageHandler.h"
// for connections
#import "TargetProperties.h"
// iso14443 connection
#import "ISO14443Connection.h"
// NDEF connection
#import "NDEFTagConnection.h"
#import "NDEFMessage.h"
#import "NDEFRecord.h"
#import "NDEFRecordType.h"
// ISO15693 connection
#import "ISO15693Connection.h"
// MifareUL connection
#import "MifareULConnection.h"
// MifareClassic connection
#import "MifareClassicConnection.h"
//P2P connection
#import "NFCIPConnection.h"
#import "NdefPushClient.h"



