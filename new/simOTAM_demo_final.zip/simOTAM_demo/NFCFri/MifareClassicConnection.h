////////////////////////////////////////////////////
//
//  Copyright 2013 CHT. All rights reserved.
//
////////////////////////////////////////////////////


#import <Foundation/Foundation.h>

#define MifareClassicConnection id <_MifareClassicConnection>

#define BLOCK_SIZE 0x00000010//	Size of a MIFARE Classic block (in bytes)
#define	SIZE_1K    0x00000400//	Tag contains 16 sectors, each with 4 blocks.
#define	SIZE_2K    0x00000800//	Tag contains 32 sectors, each with 4 blocks.
#define	SIZE_4K    0x00001000//	Tag contains 40 sectors.
#define	SIZE_MINI  0x00000140//	Tag contains 5 sectors, each with 4 blocks.
#define TYPE_CLASSIC 0x00000000//	A MIFARE Classic tag
#define	TYPE_PLUS    0x00000001//	A MIFARE Plus tag
#define	TYPE_PRO     0x00000002//	A MIFARE Pro tag
#define	TYPE_UNKNOWN 0xffffffff//	A MIFARE Classic compatible card of unknown type
  
  
@protocol _MifareClassicConnection


- (void) close;
- (void) connect;
- (BOOL) authenticateSectorWithKeyA:(int) sectorIndex:(NSData*) key: (NSData*) uid;
- (BOOL) authenticateSectorWithKeyB:(int) sectorIndex:(NSData*) key: (NSData*) uid;
- (int) blockToSector:(int) blockIndex;
- (void) decrement:(int)blockIndex:(int)value;
- (int)	getBlockCount;
- (int)	getBlockCountInSector:(int) sectorIndex;
- (int)	getMaxTransceiveLength;
- (int)	getSectorCount;
- (int)	getSize;
- (int)	getTimeout;
- (int)	getType;
- (void) increment:(int) blockIndex:(int) value;
- (BOOL) isConnected;

- (NSData*) readBlock:(int) blockIndex;

- (void) restore:(int) blockIndex;
- (int) sectorToBlock:(int) sectorIndex;
- (void) setTimeout:(int) timeout;
- (NSData*) transceive:(NSData*) data;
- (void) transfer:(int) blockIndex;

- (BOOL) writeBlock:(int) blockIndex:(NSData*) writeData;
- (BOOL) erase:(NSData*) uid;
@end
