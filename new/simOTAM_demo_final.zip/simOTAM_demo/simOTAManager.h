//
//  simOTAManager.h
//  simOTAManager
//
//  Created by 722 on 13/8/26.
//  Copyright (c) 2013年 722. All rights reserved.
//

#import <Foundation/Foundation.h>

//frankou
@interface simOTAManager : NSObject{
@private
    int lib_status;
    unsigned cmds_bytes_num;
    unsigned cur_cmds_bytes_num;
    unsigned cur_apdu_num;
    unsigned apdus_num;
    unsigned apdus_index;
    NSMutableArray *apdus;
    BOOL innerThreadStopFlag;
    unsigned char curCmd;
    CFWriteStreamRef writeStream;
    CFReadStreamRef readStream;
    NSMutableArray *recvBuf;
    bool endOfApdu;
    int errCode;
}

//
-(simOTAManager*) initWithServerIP:(NSString*)ip Port:(UInt32) port;
-(simOTAManager*) init; 
-(BOOL) destroy;
-(BOOL) check;
-(BOOL) checkOTAServerConnection;
-(BOOL) requestInstall;
-(unsigned) getApduNum;
-(NSMutableArray*) getApduByNum:(unsigned) num;
-(BOOL) reponse_ok;
-(BOOL) reponseWithData:(NSData*) data;
-(NSData*) getApdu;
-(BOOL) check_end_of_apdus;
-(BOOL) getErrorCode;
-(BOOL) requestDelete;
@end
